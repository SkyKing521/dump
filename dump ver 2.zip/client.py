import asyncio
import websockets
import json
import sys
from datetime import datetime

from app.schemas import ContactsSchema, AuthSchema, Auth


class MessengerClient:
    def __init__(self):
        self.websocket = None
        self.user_id = None
        self.username = None
        self.contacts = {}

    async def connect(self):
        self.websocket = await websockets.connect("ws://localhost:8765")

    async def register(self, username: str, password: str):
        auth = Auth()
        auth.type = "register"
        auth.password = password
        auth.username = username
        sh = AuthSchema();
        res = sh.dumps(auth)
        await self.websocket.send(res)
        try:
            response = await self.websocket.recv()
            return json.loads(response)
        except Exception as e:
            print(e)
            return None

    async def login(self, username: str, password: str):
        auth = Auth();
        auth.type = "login"
        auth.password = password
        auth.username = username
        sh = AuthSchema()
        res = sh.dumps(auth)
        await self.websocket.send(res)
        response = await self.websocket.recv()
        return json.loads(response)

    async def handle_messages(self):
        try:
            async for message in self.websocket:
                data = json.loads(message)
                self.process_server_message(data)
        except websockets.ConnectionClosed:
            print("\nСоединение с сервером разорвано")

    def process_server_message(self, data: dict):
        if data.get('type') == 'error':
            print(f"\nОшибка: {data.get('message')}")
        elif data.get('type') == 'auth_success':
            self.user_id = data['user']['id']
            self.username = data['user']['username']
            print("\nУспешная аутентификация!")
        elif data.get('type') == 'private_message':

            print(f"\n[ЛС от {data['sender_id']}]: {data['content']}")


        elif data.get('type') == 'group_message':
            print(f"\n[Группа {data['group_id']}]: {data['sender_id']}: {data['content']}")
        elif data.get('type') == 'contacts':
            self.print_contacts(data)
        else:
            return

    def print_contacts(self, data: ContactsSchema):
        print("Контакты")
        for cn in data['contacts']:
            self.contacts[cn['user_name']]=cn['user_id']
            print(f"user_name {cn['user_name']}, user_id {cn['user_id']}")

    async def send_private_message(self, receiver: str, content: str):
        await self.websocket.send(json.dumps({
            'type': 'private_message',
            'receiver_id': receiver,
            'content': content
        }))

    async def send_group_message(self, group_id: int, content: str):
        await self.websocket.send(json.dumps({
            'type': 'group_message',
            'group_id': group_id,
            'content': content
        }))


async def main():
    client = MessengerClient()
    await client.connect()

    action_done = 0
    while  action_done==0:
    # Выбор действия
        action = input("Регистрация (r) или Вход (l)? ").lower()
        username = input("Имя пользователя: ")
        password = input("Пароль: ")


        if action == 'r':
            response = await client.register(username, password)
            print(response)
            action_done = 1
        elif action == 'l':
            response = await client.login(username, password)
            print(response)
            action_done = 1
        else:
            print("Неизвестное действие")


        if response:
            if 'error' in response:
                print(f"Ошибка: {response['error']}")
                return
        else:
            return

    # Запуск обработки сообщений
    asyncio.create_task(client.handle_messages())

    print("Доступные команды:")
    print("/list получить список контактов пользователя")
    print("/msg <получатель> <сообщение> - личное сообщение")
    print("/group <id группы> <сообщение> - сообщение в группу")
    print("/exit - выход")

    # Основной цикл ввода команд
    while True:
        try:
            command = await asyncio.get_event_loop().run_in_executor(
                None, input, f"[{client.username}] > "
            )
            if command.startswith('/list'):
                print("запрос контакта")
            elif command.startswith('/msg'):
                _, receiver, *content = command.split()
                await client.send_private_message(receiver, ' '.join(content))

            elif command.startswith('/group'):
                _, group_id, *content = command.split()
                await client.send_group_message(int(group_id), ' '.join(content))


            elif command == '/exit':
                await client.websocket.close()
                break

            else:
                print("Доступные команды:")
                print("/list получить список контактов пользователя")
                print("/msg <получатель> <сообщение> - личное сообщение")
                print("/group <id группы> <сообщение> - сообщение в группу")
                print("/exit - выход")

        except KeyboardInterrupt:
            await client.websocket.close()
            break


if __name__ == "__main__":
    asyncio.run(main())