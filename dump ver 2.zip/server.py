import asyncio
import websockets
import json
import hashlib
import os
from datetime import datetime, timezone
from marshmallow import ValidationError
from sqlalchemy.ext.asyncio import async_sessionmaker, AsyncSession
from app.crud import UserCRUD, GroupCRUD, MessageCRUD
from app.schemas import (
    AuthSchema,
    CreateGroupSchema,
    PrivateMessageSchema,
    UserSchema,
    GroupSchema,
    MessageSchema
)
from app.database import engine, Base
from app.models import Message


class MessengerServer:
    def __init__(self):
        # список активных соединений вместе с номером пользователя (user_id) это словарь user-ID->websocket
        self.active_connections = {}
        # для работы с БД асинхронная сессия
        self.async_session = async_sessionmaker(engine, expire_on_commit=False)#get_async_session()

    # region Database Initialization
    async def init_db(self):
        async with engine.begin() as conn:
            await conn.run_sync(Base.metadata.create_all)
        print("Database initialized")
    # endregion

    # region Connection Handling обработка входящих подключений
    async def handle_connection(self, websocket):
        try:
            print(f"connect from {websocket}")
            #Получение пакета
            async for message in websocket:
                await self.route_message(websocket, message)
        except websockets.ConnectionClosed:
            await self.handle_disconnect(websocket)

    # обработка отключений
    async def handle_disconnect(self, websocket):
        user_id = next((uid for uid, ws in self.active_connections.items() if ws == websocket), None)
        if user_id:
            del self.active_connections[user_id]
            print(f"User {user_id} disconnected")

    # endregion

    # определение обработчика сообщения
    async def route_message(self, websocket, raw_data):
        try:
            data = json.loads(raw_data)
            message_type = data.get('type')

            schema = self.get_schema_for_type(message_type)
            if not schema:
                await self.send_error(websocket, f"Invalid message type: {message_type}")
                return

            # разоранный по правилам схемы dict из JSON
            validated = schema.load(data)

            # получение обрабочка по имени
            handler = getattr(self, f"handle_{validated['type']}", None)

            # ВЫЗОВ ОБработчика
            if handler:
                await handler(websocket, validated)
            else:
                await self.send_error(websocket, f"Unhandled message type: {message_type}")

        except json.JSONDecodeError:
            await self.send_error(websocket, "Invalid JSON format")
        except ValidationError as e:
            await self.send_error(websocket, f"Validation error: {e.messages}")
        except Exception as e:
            await self.send_error(websocket, f"Server error: {str(e)}")

    # по словарю получаем, какая схема JSON какому типу сообщения нужна
    def get_schema_for_type(self, message_type):
        return {
            'register': AuthSchema(),
            'login': AuthSchema(),
            'create_group': CreateGroupSchema(),
            'private_message': PrivateMessageSchema(),
            'group_message': MessageSchema()
        }.get(message_type)

    # endregion

    # region Response Helpers
    async def send_success(self, websocket, message_type, data=None):
        response = {
            "type": message_type,
            "status": "success",
            "timestamp": datetime.now(timezone.utc).isoformat()
        }
        if data:
            response["data"] = data
        await websocket.send(json.dumps(response))

    async def send_error(self, websocket, message):
        error_msg = {
            "type": "error",
            "status": "error",
            "timestamp": datetime.now(timezone.utc).isoformat(),
            "message": message
        }
        await websocket.send(json.dumps(error_msg))

    # endregion

    # region Handlers
    async def handle_register(self, websocket, data):
        try:
            async with self.async_session() as session:
                # Генерация нового salt для каждого пользователя
                salt = os.urandom(32)

                # Создание пользователя с раздельным хранением salt и хеша
                user_data = {
                    "username": data['username'],
                    "salt": salt.hex(),
                    "password_hash": self.hash_password(data['password'], salt)
                }

                user = await UserCRUD.create_user(session, user_data)
                self.active_connections[user['id']] = websocket
                await self.send_success(websocket, "auth_success", user)

        except Exception as e:
            await self.send_error(websocket, str(e))

    async def handle_login(self, websocket, data):
        try:
            # правильное получени сесии асихронной работы с БД
            async with self.async_session() as session:
                # Получаем пользователя как SQLAlchemy модель
                user_model = await UserCRUD.get_user_by_username(session, data['username'])

                # Конвертируем модель в словарь через схему
                user_dict = UserSchema().dump(user_model)
                salt = bytes.fromhex(user_dict['salt'])

                # Проверяем пароль
                test_hash = self.hash_password(data['password'], salt)

                if user_dict['password_hash'] == test_hash:
                    self.active_connections[user_dict['id']] = websocket
                    del user_dict['password_hash']
                    del user_dict['salt']
                    await self.send_success(websocket, "auth_success", user_dict)
                    return

            await self.send_error(websocket, "Invalid credentials")

        except Exception as e:
            await self.send_error(websocket, str(e))

    async def handle_create_group(self, websocket, data):
        try:
            async for session in self.session:
                group = await GroupCRUD.create_group(session, data)
                await self.send_success(websocket, "group_created", group)

        except Exception as e:
            await self.send_error(websocket, str(e))


    async def handle_private_message(self, websocket, data):
        try:
            user_id = list(self.active_connections.keys())
            [list(self.active_connections.values()).index(websocket)]

            async with self.async_session() as session:
                message = await MessageCRUD.create_private_message(session, data, user_id[0])
                await self.send_private_message(message, session)
                await self.send_success(websocket, "message_sent", data)

        except Exception as e:
            await self.send_error(websocket, str(e))

    async def send_private_message(self, message: Message, session: AsyncSession):
        """
        Отправляет приватное сообщение конкретному пользователю
        и обновляет статус доставки
        """
        try:
            # Сериализация сообщения
            message_data = {
                "type": "private_message",
                "id": message.id,
                "sender_id": message.sender_id,
                "content": message.content,
                "created_at": message.created_at.isoformat(),
                "is_group": False
            }

            # Получаем соединение получателя
            receiver_ws = self.active_connections.get(message.receiver_id)

            if receiver_ws:
                try:
                    # Отправляем сообщение через WebSocket
                    await receiver_ws.send(json.dumps(message_data))

                    # Обновляем статус доставки в БД
                    #async with self.async_session() as session:
                    #    async with session.begin():
                    message.is_delivered = True
                    message.delivered_at = datetime.now(timezone.utc)
                    #session.add(message)
                    await session.commit()

                except websockets.ConnectionClosed:
                    # Обработка закрытого соединения
                    #async with self.async_session() as session:
                    #    async with session.begin():
                    message.is_delivered = False
                    #session.add(message)
                    await session.commit()

                    # Удаляем из активных подключений
                    del self.active_connections[message.receiver_id]
                    print(f"User {message.receiver_id} disconnected")

            else:
                # Помечаем сообщение как недоставленное
                #async with self.async_session() as session:
                    #async with session.begin():
                message.is_delivered = False
#                session.add(message)
                await session.commit()

        except Exception as e:
            print(f"Error sending private message: {str(e)}")
            # Логирование ошибки или повторная попытка отправки

    # endregion

    # region Utility Methods
    @staticmethod
    def hash_password(password: str, salt: bytes) -> str:
        """Генерация хеша пароля с использованием предоставленного salt"""
        key = hashlib.pbkdf2_hmac(
            'sha256',
            password.encode('utf-8'),
            salt,
            100000
        )
        return key.hex()
    # endregion

## асинхронный главный процедуре
async def main():
    # создаём объект сервера
    server = MessengerServer()
    # инициализация БД
    await server.init_db()

    # делаем аснхронную карутину для обработки поступающих соединений
    async with websockets.serve(server.handle_connection, "localhost", 8765):
        print("Messenger Server running on ws://localhost:8765")
        await asyncio.Future()


if __name__ == "__main__":
    asyncio.run(main())