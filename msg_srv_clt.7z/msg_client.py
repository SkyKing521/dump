import asyncio
import websockets
import json
import sys
from datetime import datetime, timezone
from PyQt6.QtCore import QObject,pyqtSignal
from marshmallow import ValidationError


from app.msg_schemas import (
    UserContactsSchema,
    AuthSchema,
    Auth,
    UserContactsClass,
    OneContactClass,
    PrivateMessageSchema,
    PrivateMessageClass,
    GroupMessageSchema,
    generate_message_id, parse_custom_datetime
)

# ========== Signals!!!
class MessengerClientSignals(QObject):
    on_user_contacts= pyqtSignal() # для оповещения, что получены контакты
    on_private_message = pyqtSignal(PrivateMessageClass) # для оповещения, что получено сообщение

# =============== class!!!!!
class MessengerClient:
    def __init__(self):
        self.websocket = None
        self.user_id : int = None
        self.username : str = None
        self.selected_contact : OneContactClass = None
        self.contacts : list[OneContactClass] = list[OneContactClass]()
        self.server_url:str = 'ws://localhost:8765'
        self.chats:dict[int,list[PrivateMessageClass]] = dict[int,list[PrivateMessageClass]]()

        self.msg_rvc_task = None

        self.msg_to_skip = 0

        # сигналы
        self.signals : MessengerClientSignals = MessengerClientSignals()


    # соединение с сервером
    async def connect(self):
        if not self.websocket:
            self.websocket = await websockets.connect(self.server_url)

    # дял определения, соединение есть или нет
    def IsConnected(self)->bool:
        if not self.websocket:
            return False
        else:
            return True

    # регистрация нового пользователя
    async def register(self, username: str, password: str, email: str)->int:
        auth = Auth()
        auth.type = "register"
        auth.password = password
        auth.username = username
        auth.email = email
        sh = AuthSchema()
        res = sh.dumps(auth)
        try:
            await self.websocket.send(res)
            response = await self.websocket.recv()
            self.msg_to_skip+=1
            data= json.loads(response)
            if data['type']=='auth_success':
                self.user_id = data['data']['id']
                print(f"зашли как с {username} ИД {self.user_id}")
                return self.user_id
            else:
                return -1
        except Exception as e:
            print(e)
            return -1

    # для логина по имеющемуся пользователю
    async def login(self, username: str, password: str):
        auth = Auth()
        auth.type = "login"
        auth.password = password
        auth.username = username
        sh = AuthSchema()
        res = sh.dumps(auth)
        await self.websocket.send(res)
        print("отправили запрос логин")
        try:
            response = await self.websocket.recv()
            self.msg_to_skip+=1
            print("получили ответ логин")
            data= json.loads(response)
            if data['type']=='auth_success':
                self.user_id = data['data']['id']
                print(f"зашли как с {username} c ИД {self.user_id}")

                # if not self.msg_rvc_task:
                #     self.msg_rvc_task = asyncio.create_task(self.process_incoming_messages())

                # await self.get_contacts()

                return self.user_id, None
            else:
                return -1, None
        except Exception as e:
            print(e)
            return -1, e

    # обработка сообщения
    async def process_incoming_messages(self):
        try:
            i = 0
            async for message in self.websocket:
                i+=1
                if  i== self.msg_to_skip:
                    break
            async for message in self.websocket:
                await self.process_server_message(self.websocket, message)
        except websockets.ConnectionClosed:
            print("\nСоединение с сервером разорвано")
        except asyncio.CancelledError:
            pass

    # маршрутизация обработчика сообщения
    async def process_server_message(self, websocket, message):
        try:
            data = json.loads(message)
            if data.get('type') == 'error':
                print(f"\nОшибка при обработке на сервере: {data.get('message')}")
                return

            message_type: str = data.get('type')

            schema = self.get_schema_for_type(message_type)
            if not schema:
                return

            print(f"получили сообщение типа {message_type}")
            # разобранный по правилам схемы dict из JSON
            validated = schema.load(data)

            # получение обработка по имени
            handler = getattr(self, f"handle_{validated['type']}", None)

            if handler:
                await handler(websocket, validated)
            else:
                print(f"Unhandled message type: {message_type}")

        except json.JSONDecodeError:
            print( "client Invalid JSON format")
        except ValidationError as e:
            print( f"client Validation error: {e.messages}")
        except Exception as e:
            print( f"client error: {str(e)}")

    #region handlers
        # по словарю получаем, какая схема JSON какому типу сообщения нужна
    def get_schema_for_type(self, message_type):
        return {
            'auth_success': AuthSchema(),
            'private_message' : PrivateMessageSchema(),
            'group_message' : GroupMessageSchema(),
            'user_contacts' : UserContactsSchema()
        }.get(message_type)

    # обработка личного сообщения
    async def handle_private_message(self, websocket, data: dict):
        print(f"\n[ЛС от {data['sender_id']}]: {data['content']}")
        m = PrivateMessageClass.model_validate(data)
        if not m.sender_id in self.chats.keys():
            self.chats[data['sender_id']]=[]
        self.chats[data['sender_id']].append(m)
        self.signals.on_private_message.emit(m)

    # обработка группового сообщения
    async def handle_group_message(self, websocket,data: dict):
        print(f"\n[Группа {data['group_id']}]: {data['sender_id']}: {data['content']}")

    # Printing contacts
    async def handle_user_contacts(self, websocket,data: dict):
        print("Контакты")
        for cn in data['contacts']:
            c = OneContactClass()
            c.user_id = cn['user_id']
            c.user_name=cn['user_name']
            c.custom_nickname = cn['custom_nickname']
            c.status = cn['status']
            self.contacts.append(c)
            print(f"user_name {cn['user_name']}, user_id {cn['user_id']}")
        for gp in data['groups']:
            print(f"user_name {gp['group_name']}, user_id {gp['group_id']}")
        self.signals.on_user_contacts.emit()

    #endrefion

    #region выбор контакта

    def select_contact(self,contact_name: str):
        self.selected_contact = None
        for c in self.contacts:
            if contact_name in {c.user_name,c.custom_nickname}:
                self.selected_contact = c
        return
    #endregion

    #region выбор контакта по ИД

    def select_contact_by_user_id(self,user_id: str):
        self.selected_contact = None
        for c in self.contacts:
            if user_id == c.user_id :
                self.selected_contact = c
        if self.selected_contact:
            if not self.selected_contact.user_id in self.chats.keys():
                self.chats[self.selected_contact.user_id]=[]
        return
    #endregion

    # sending private message
    async def send_private_message(self, receiver: int, content: str):
        # Получаем текущее время с информацией о часовой зоне (UTC)
        now = datetime.now(timezone.utc).replace(tzinfo=None)
        # Форматируем в нужный вид
        atime = now
        formatted_time = atime.strftime('%Y-%m-%dT%H:%M:%S.%f')

        m = PrivateMessageClass(
            id = generate_message_id(),
            type = 'private_message',
            sender_id = self.user_id,
            receiver_id = int(receiver),
            content = content,
            created_at = atime
        )

        try:
            await self.websocket.send(json.dumps({
                'id' : m.id,
                'type': 'private_message',
                'sender_id' : self.user_id,
                'receiver_id': receiver,
                'content': content,
                'created_at' : formatted_time
            }))

            rcv = int(receiver)

            if not rcv in self.chats.keys():
                self.chats[rcv] = []
            self.chats[rcv].append(m)
            return m
        except Exception as e:
            print(f"client send_private_message: {e}")
            raise



    # sending contacts response
    async def get_contacts(self):
        await self.websocket.send(json.dumps({
            'type': 'get_user_contacts',
        }))


    # sending group message
    async def send_group_message(self, group_id: int, content: str):
        await self.websocket.send(json.dumps({
            'type': 'group_message',
            'group_id': group_id,
            'content': content
        }))


#region ===========MAIN Это основная функция системы
async def main():
    client = MessengerClient()
    await client.connect()

    action_done = 0
    # tries : int = 0;
    while  action_done==0:
    # Выбор действия
        action = input("Регистрация (r) или Вход (l)? ").lower()

        if action in {'1','2','3','4','5'}:
            username='user'+action
            password=username+username
            action='l'
        else:
            username = input("Имя пользователя: ")
            password = input("Пароль: ")
            email = username+'@email.com'


        if action == 'r':
            response = await client.register(username, password,email)
            # tries+=1
        elif action == 'l':
            response,err = await client.login(username, password)
            # tries+=1
        else:
            print("Неизвестное действие")


        if response<0:
            print(f'Ещё раз ввести надо')
        else:
            action_done = 1 # выходим, раз есть авторизация


    # Запуск обработки сообщений
    asyncio.create_task(client.process_incoming_messages())

    print("Доступные команды:")
    print("/list получить список контактов пользователя")
    print("/msg <получатель> <сообщение> - личное сообщение")
    print("/group <id группы> <сообщение> - сообщение в группу")
    print("/exit - выход")

    # Основной цикл ввода команд
    while True:
        try:
            command = await asyncio.get_event_loop().run_in_executor(
                None, input, f"[{client.username}] > "
            )
            if command.startswith('/list'):
                await client.get_contacts()
            elif command.startswith('/msg'):
                _, receiver, *content = command.split()
                await client.send_private_message(receiver, ' '.join(content))

            elif command.startswith('/group'):
                _, group_id, *content = command.split()
                await client.send_group_message(int(group_id), ' '.join(content))

            elif command.startswith('/prn'):
                _, chat_id, *content = command.split()
                rcv = int(chat_id)
                if rcv in client.chats.keys():
                    for m in client.chats[rcv]:
                        print(f"-->own:{m.sender_id==client.user_id} {m.created_at}: {m.content}")

            elif command == '/exit':
                await client.websocket.close()
                break

            else:
                print("Доступные команды:")
                print("/list получить список контактов пользователя")
                print("/msg <получатель> <сообщение> - личное сообщение")
                print("/group <id группы> <сообщение> - сообщение в группу")
                print("/exit - выход")

        except KeyboardInterrupt:
            await client.websocket.close()
            break
#endregion

if __name__ == "__main__":
    asyncio.run(main())